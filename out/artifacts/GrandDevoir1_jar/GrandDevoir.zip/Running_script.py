#!/usr/bin/env python3

import os

os.system('')
os.system('java -jar GrandDevoir1.jar');